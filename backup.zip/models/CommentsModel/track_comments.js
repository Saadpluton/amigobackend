import mongoose from "mongoose";

const trackCommentsSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "userId field is required"]
  },
  parentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "TrackComment",
    //required: [true, "userId field is required"]
  },
  trackId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Song",
    //required : [true ,"artistId field is required"]
  },
  comments: {
    type: String
  },
  createAt: {
    type: Date,
    default: Date.now()
  }
});

export const TrackComments = mongoose.model("TrackComment", trackCommentsSchema)
