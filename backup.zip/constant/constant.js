const PNG = 'image/png'
const JPG = 'image/jpg'
const JPEG = 'image/jpeg'
const MP3 = 'audio/mp3'
const MPEG = 'audio/mpeg'
const PATH = "https://amigobackend.herokuapp.com/"
const TOTALLISTENERS = 500
const TOTALLIKES = 301

export {PNG,JPG,JPEG,MP3,MPEG,PATH,TOTALLISTENERS,TOTALLIKES}

